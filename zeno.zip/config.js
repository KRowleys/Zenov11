/*
  >> Control <<
*/
global.owner = ['6283896579251']
global.ownername = "Kay"
global.connect = true // ubah ke false klo mau connect lewat qrcode 
global.antilink = false
global.autotyping = false

/*
  
  >> Payment <<
*/
global.dana = "XXXX"
global.gopay = "XXXX"
global.ovo = "XXXX"
global.qris = "XXXX"

/*
  >> Message <<
*/
global.mess = {
"ketua": " ⇝ Lu Siapa Kontol",
"prem": "⇝ Lu Siapa Kontol",
"premium": "⇝ Lu Siapa Kontol",
"japost": " -- Format Japost Tidak Tersedia -- ",
"rekber": " -- List Rekber Tidak Tersedia -- ",
"owner": " ⇝ Lu Siapa Kontol"
}

/*
  >> MISC <<
*/
global.tele = "t.me/kayrowley"
global.tele2 = "t.me/kayrowley"
global.waMe = "wa.me/6283896579251"
global.tutorialBot = "https://youtube.com/@drayyyxd" // Untuk menggampangkan buyer awam saat beli panel 
global.versionofscript = "8.0"
global.url = "https://files.catbox.moe/i7jxyz.jpg" // buat banner
global.urlbanner = "https://files.catbox.moe/zay0u6.jpg" // buat banner 2
global.url2 = "https://t.me/kayrowley" // isi url bebas buat reply
global.packname = "kay?" // sticker
global.author = "rowley" // sticker
global.group = "-" // isi group bebas lu
global.idCH = "120363333509194874@newsletter"
global.xchannel = {
	jid: '120363333509194874@newsletter'
	}
	